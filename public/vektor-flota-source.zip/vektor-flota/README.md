# Vektor Flota · Grupo Trans Plus (TMF Panamá)

## Requisitos
- Node.js 20+

## Instalación y ejecución local
```bash
npm install
npm run dev
```
La aplicación se abrirá en `http://localhost:3000`.

## Conexión con Google Drive / Google Sheets
Por seguridad, este paquete incluye `firebase-applet-config.example.json` en lugar de credenciales activas.
Para habilitar el botón "Sign in with Google" en local o en Vercel:
1. Copia `firebase-applet-config.example.json` a `firebase-applet-config.json`.
2. Completa los valores de tu proyecto Firebase / Google Cloud (con Google Auth habilitado y tu dominio autorizado en Firebase Authentication).
